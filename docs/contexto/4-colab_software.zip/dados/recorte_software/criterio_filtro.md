# Filtro de software

Grupos extraídos do notebook: 111, 112, 113, 114, 115, 116, 117, 131, 161, 162, 163, 164, 165, 168, 171, 172, 173, 174. São 62 códigos de serviço no CATSER local.

O filtro exige `material_ou_servico == "S"` e `cod_item_catalogo` pertencente aos códigos CATSER desses grupos. A comparação remove apenas o sufixo decimal de zeros dos códigos. Não exige status ativo no catálogo, pois inclui contratações históricas.

A classificação segue o catálogo local atual; não reconstrói versões históricas do CATSER. Serviços sem correspondência não são incluídos e sua quantidade é registrada.

As colunas originais são preservadas. Os nomes e códigos CATSER são acrescentados por mapeamento único, sem multiplicar linhas. Não são removidas duplicatas. Os arquivos COMPRA contêm os IDs relacionados aos itens selecionados em qualquer ano. Itens com compras não encontradas são mantidos e os IDs ausentes são listados. Ainda não há join entre compras e itens.
